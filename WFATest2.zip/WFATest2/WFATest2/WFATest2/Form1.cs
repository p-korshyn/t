﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace WFATest2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        bool isChange = false;
        string date, task;
        private void button3_Click(object sender, EventArgs e)
        {
            //del
            listBox2.Items.Remove(listBox2.Items[listBox2.SelectedIndex]);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //done
            listBox2.Items.Add(listBox1.Items[listBox1.SelectedIndex]);
            listBox1.Items.Remove(listBox1.Items[listBox1.SelectedIndex]);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //change
            textBox2.Text = "";
            textBox1.Text = "";
            string str = (string)listBox1.Items[listBox1.SelectedIndex];
            string[] mas = str.Split(' ');
            textBox2.Text = mas[0];
            for(int i = 1; i<mas.Length; i++)
            {
                textBox1.Text = textBox1.Text+mas[i]+" ";
            }
            isChange = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (isChange)
            {
                listBox1.Items[listBox1.SelectedIndex] = textBox2.Text + " " + textBox1.Text;
            }
            else
            {
                MessageBox.Show("Ошибка! Вы не изменили задачу.");
            }
            textBox1.Text = "";
            textBox2.Text = "";
            isChange = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //create
            task = textBox1.Text;
            date = textBox2.Text;
            listBox1.Items.Add(date + " " + task);
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}
